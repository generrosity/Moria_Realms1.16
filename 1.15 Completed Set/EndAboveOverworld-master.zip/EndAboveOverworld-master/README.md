# EndAboveOverworld
A Minecraft datapack to add a link between the top of the Overworld and the bottom of the End.

# Requires
- Minecraft 1.13 / 1.14 / 1.15 / 1.16

# Use
1. Download the package and unzip it
2. Copy/paste the entire "EndAboveOverworld/" folder in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.

# Author
- Name : FunkyToc 
- Website : http://naturize.fr
- Contact : http://naturize.fr/contact
- Original concept by franswa : https://www.youtube.com/watch?v=ZZBu9OcX17E

# Thanks
...
