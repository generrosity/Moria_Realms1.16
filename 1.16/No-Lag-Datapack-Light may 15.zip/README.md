# No-Lag-Datapack-Light v.1.2.3

With the No Lag Datapack Light from 2mal3, the lag in the world is reduced with 5 different and light methods.

Mehods:
  - Multiple xp orbs are combined into a single xp orb.
  - If a specified number of tnt is exceeded, all tnts are removed.
  - Items despawn earlier.
  - The collision of farm animals is switched off.
  - Only a specific number of entitys can be on one block.

 Installation:
  1. Download the file.
  2. Unzip the file.
  3. Move the folder in the file to a Datapack folder in a world of your choice.

  To uninstall, enter /function #nldl:uninstall and drag the Datapack folder from the Datapacks Order of the World.
